<?php
include $_SERVER["DOCUMENT_ROOT"]."/inc/top.php";

global $cvalarray;

// 판매중인 메인 상품 12개 Query
$sql = "select * from products p where 1=1 and ismain=1 and status=1";
$order = " order by pid desc";
$limit = " limit 12";
$query = $sql.$order.$limit;
$result = $mysqli->query($query) or die ("query error => ".$mysqli->error);
while ($rs = $result->fetch_object()) {
    $rsc_main[] = $rs;
}

// 판매중인 추천 상품 4개 Query
$sql = "select * from products p where 1=1 and isrecom=1 and status=1";
$order = " order by pid desc";
$limit = " limit 4";
$query = $sql.$order.$limit;
$result = $mysqli->query($query) or die ("query error => ".$mysqli->error);
while ($rs = $result->fetch_object()) {
    $rsc_recom[] = $rs;
}

// 판매중인 최신 상품 5개 Query
$sql = "select * from products p where 1=1 and isnew=1 and status=1";
$order = " order by pid desc";
$limit = " limit 5";
$query = $sql.$order.$limit;
$result = $mysqli->query($query) or die ("query error => ".$mysqli->error);
while ($rs = $result->fetch_object()) {
    $rsc_new[] = $rs;
}

?>

<!-- Start slider area -->
<div class="slider-area">
    <div id="slide-list" class="carousel carousel-fade slide" data-bs-ride="carousel">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="carousel-indicators">
                        <button type="button" data-bs-target="#slide-list" data-bs-slide-to="0" class="active"></button>
                        <button type="button" data-bs-target="#slide-list" data-bs-slide-to="1"></button>
                        <button type="button" data-bs-target="#slide-list" data-bs-slide-to="2"></button>
                    </div>
                </div>
            </div>
        </div>
        <div class="carousel-inner">
            <div class="carousel-item active" data-bs-interval="3000">
                <div class="slide-wrapper">
                    <img src="img/slide-1.jpg" class="d-block w-100">
                    <div class="carousel-caption">
                        <a href="#">
                            <h3>남여공용 향수</h3>
                        </a>
                        <p>Wecome to Parfume Story</p>
                    </div>
                </div>
            </div>
            <div class="carousel-item" data-bs-interval="3000">
                <div class="slide-wrapper">
                    <img src="img/slide-2.jpg" class="d-block w-100">
                    <div class="carousel-caption">
                        <a href="#">
                            <h3>여성용 향수</h3>
                        </a>
                        <p>Wecome to Parfume Story</p>
                    </div>
                </div>
            </div>
            <div class="carousel-item" data-bs-interval="3000">
                <div class="slide-wrapper">
                    <img src="img/slide-3.jpg" class="d-block w-100">
                    <div class="carousel-caption">
                        <a href="#">
                            <h3>남성용 향수</h3>
                        </a>
                        <p>Wecome to Parfume Story</p>
                    </div>
                </div>
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#slide-list" data-bs-slide="prev">
            <span class="carousel-control-prev-icon"></span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#slide-list" data-bs-slide="next">
            <span class="carousel-control-next-icon"></span>
        </button>
    </div>
</div>
<!-- End slider area -->
<hr>
<!-- Start curation area -->
<section class="curation-area">
    <div class="curation-grid">
        <div class="curation-content">
            <p class="sub sub-color">Perfume Story MD Pick</p>
            <p class="title">큐레이션</p>
            <p class="content">
                갑자기 추워진 계절<br>
                Perfume Story가 추천하는 큐레이션을 만나보세요
            </p>
            <a href="#" class="view_more">VIEW MORE</a>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="card-group">
                <?php if(isset($rsc_recom)) foreach ($rsc_recom as $p) { ?>
                <div class="col-lg-3 col-sm-6 col-12">
                    <div class="product-card">
                        <div class="card h-100">
                            <div class="card-img"><img src="<?php echo $p->thumbnail;?>" alt="image"></div>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $p->name;?></h5>
                                <p class="card-text"><?php echo $p->content;?></p>
                            </div>
                            <div class="card-bottom"><a href="#" class="btn btn-primary float-end">구매하기</a>
                                <div class="product-price">
                                    <ins><?php echo number_format($p->sale_price);?>원</ins>
                                    <del><?php echo number_format($p->price);?>원</del>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php }?>
            </div>
        </div>
    </div>
</section>
<!-- End curation area -->
<hr>
<!-- Start new-product area -->
<div class="new-product-area">
    <div class="curation-grid">
        <div class="curation-content">
            <p class="sub sub-color">Perfume Story New Product</p>
            <p class="title">신상품 소개</p>
            <p class="content">
                갑자기 추워진 계절<br>
                Perfume Story가 추천하는 신상품을 만나보세요
            </p>
            <a href="#" class="view_more">VIEW MORE</a>
        </div>
    </div>
    <div id="new-product-list" class="carousel slide" data-bs-ride="carousel">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="carousel-indicators">
                        <button type="button" data-bs-target="#new-product-list" data-bs-slide-to="0" class="active"></button>
                        <button type="button" data-bs-target="#new-product-list" data-bs-slide-to="1"></button>
                        <button type="button" data-bs-target="#new-product-list" data-bs-slide-to="2"></button>
                        <button type="button" data-bs-target="#new-product-list" data-bs-slide-to="3"></button>
                        <button type="button" data-bs-target="#new-product-list" data-bs-slide-to="4"></button>
                    </div>
                </div>
            </div>
        </div>
        <div class="carousel-inner">
            <?php if(isset($rsc_new)) foreach ($rsc_new as $p) { ?>
            <div class="carousel-item active" data-bs-interval="3000">
                <div class="product-card-wrapper">
                    <div class="card" style="width: 18rem">
                        <div class="card-img"><img src="<?php echo $p->thumbnail;?>" alt="image"></div>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $p->name;?></h5>
                            <p class="card-text"><?php echo $p->content;?></p>
                        </div>
                        <div class="card-bottom"><a href="#" class="btn btn-primary float-end">구매하기</a>
                            <div class="product-price">
                                <ins><?php echo number_format($p->sale_price);?>원</ins>
                                <del><?php echo number_format($p->price);?>원</del>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php }?>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#new-product-list" data-bs-slide="prev">
            <span class="carousel-control-prev-icon"></span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#new-product-list" data-bs-slide="next">
            <span class="carousel-control-next-icon"></span>
        </button>
    </div>
</div>
<!-- End new-product area -->
<hr>
<!-- Start main content area -->
<div class="maincontent-area">
    <div class="curation-grid">
        <div class="curation-content">
            <p class="sub sub-color">Perfume Story Best</p>
            <p class="title">베스트 셀러</p>
            <p class="content">
                갑자기 추워진 계절<br>
                Perfume Story의 베스트 상품을 만나보세요
            </p>
            <a href="#" class="view_more">VIEW MORE</a>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <?php if(isset($rsc_main)) foreach ($rsc_main as $p) { ?>
            <div class="col-lg-3 col-sm-6 col-12">
                <div class="product-card">
                    <div class="card h-100">
                        <div class="card-img"><img src="<?php echo $p->thumbnail;?>" alt="image"></div>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $p->name;?></h5>
                            <p class="card-text"><?php echo $p->content;?></p>
                        </div>
                        <div class="card-bottom"><a href="#" class="btn btn-primary float-end">구매하기</a>
                            <div class="product-price">
                                <ins><?php echo number_format($p->sale_price);?>원</ins>
                                <del><?php echo number_format($p->price);?>원</del>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php }?>
        </div>
    </div>
</div>
<!-- End main content area -->

<!-- Start promotion area -->
<div class="promo-area">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-6">
                <div class="single-promo">
                    <i class="fa fa-refresh"></i>
                    <p>30일내 환불</p>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="single-promo">
                    <i class="fa fa-truck"></i>
                    <p>무료 배송</p>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="single-promo">
                    <i class="fa fa-lock"></i>
                    <p>안전한 결재</p>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="single-promo">
                    <i class="fa fa-gift"></i>
                    <p>신상 입고</p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End promotion area -->

<?php
include $_SERVER["DOCUMENT_ROOT"]."/inc/bot.php";
?>