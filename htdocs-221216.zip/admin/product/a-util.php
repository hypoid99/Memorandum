<?php
/*
echo '<script>console.log("'.$sql_notice.'")</script>';
echo '<script>alert("isMobile : '.$isMobile .'");</script>';

echo "<script>\r\n//<![CDATA[\r\nif(!console){var console={log:function(){}}}";
foreach ($result as $key => $line) {
        $key = addslashes($key);
        $line = addslashes($line);
        echo "console.log(\"${key} : {$line}\");";
}
echo "\r\n//]]>\r\n</script>";   
*/
?>

<?php
$html  = '';
$html .= '<div class="container" style="text-align:right;background-color:#FFF;color:#555;font-size:12px;">';  
if (mbw_is_login()) {
 if (mbw_get_user("fn_user_name")!="") $html .= '<span class="text-user-welcome">'.mbw_get_user("fn_user_name").'님의 방문을 환영합니다!</span>&nbsp;&nbsp;';
 $html .= '<a href="'.mbw_get_user_url("user_info").'" ><span class="btn-user-info">회원정보</span></a><span style="padding:0 10px;font-size:11px;vertical-align:1px;">|</span>';  
 $html .= '<a href="'.site_url().'/?mb_user=logout" ><span class="btn-user-logout">로그아웃</span></a>';  
}else{          
 $html .= '<a href="'.mbw_get_user_url("login").'" ><span class="btn-user-login">로그인</span></a><span style="padding:0 10px;font-size:11px;vertical-align:1px;">|</span>';
 $html .= '<a href="'.mbw_get_user_url("register").'" ><span class="btn-user-join">회원가입</span></a>';
}       
$html .= '</div>';  
echo $html;
?>