<?php
include $_SERVER["DOCUMENT_ROOT"]."/inc/html_header.html";
?>

<?php 
session_start();
include $_SERVER["DOCUMENT_ROOT"]."/inc/dbcon.php";
include $_SERVER["DOCUMENT_ROOT"]."/inc/lang.php";

if (isset($_SESSION['UID'])) {
    $user = $_SESSION['UID'];
}

function isLanguage($n) {
    switch ($n) {
        case "kr" : $rs="한국어";
        break;
        case "en" : $rs="English";
        break;
        case "jp" : $rs="日本語";
        break;
    }
    return $rs;
}
?>

<!-- Start header area -->
<div class="header-area">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="usermenu-left">
                    <ul>
                        <li><a href="#"><i class="fa fa-user"></i> 나의 쇼핑정보</a></li>
                        <li><a href="#"><i class="fa fa-heart"></i> 최근 본 상품</a></li>
                        <li><a href="#"><i class="fa fa-shopping-cart"></i> 장바구니</a></li>
                        <?php
                            $html = '';
                            if (isset($_SESSION['AUID'])) {
                            $html = '<li><a href="/admin/product/product_list.php" ><i class="fa fa-gift"></i> 상품등록</a></li>';  
                            } 
                            echo $html;
                        ?>
                    </ul>
                </div>
            </div>
            <div class="col-md-4">
                <div class="usermenu-right">
                    <ul>
                        <li>
                            <?php
                                $html = '';
                                if (isset($_SESSION['UID'])) {
                                    $html .= '<a href="#" ><i class="fa fa-heart"></i> '.$user.'님</a>';
                                } else {          
                                    $html = '';
                                }       
                                echo $html;
                            ?>
                        </li>
                        <li>
                            <?php
                                $html = '';
                                if (isset($_SESSION['UID'])) {
                                    $html .= '<a href="/member/logout.php" ><i class="fa fa-unlock"></i> 로그아웃</a>';  
                                } else {          
                                    $html .= '<a href="/member/login.php"><i class="fa fa-user"></i> 로그인</a>';
                                }       
                                echo $html;
                            ?>
                        </li>
                        <li>
                            <?php
                                $html = '';
                                if (isset($_SESSION['UID'])) {
                                    $html .= '<a href="/member/member_info.php"><i class="fa fa-user"></i> 회원정보</a>';  
                                } else {          
                                    $html .= '<a href="/member/signup.php"><i class="fa fa-user"></i> 회원가입</a>';
                                }       
                                echo $html;
                            ?>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End header area -->

<!-- Start site branding area -->
<div class="site-branding-area">
    <div class="container">
        <div class="row">
            <div class="col-sm">
                <div class="logo">
                    <h1><a href="/"><span>Perfume Story 2022</span></a></h1>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End site branding area -->

<!-- Start mainmenu area -->
<div class="main-menu-area">
    <nav class="navbar navbar-expand-lg sticky-top p-0">
        <div class="container">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainmenu-navbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="mainmenu-navbar">
                <ul class="navbar-nav">
                    <li class="nav-item px-1 active"><a class="nav-link" href="/">Perfume Story</a></li>
                    <li class="nav-item px-1"><a class="nav-link" href="#">기획전</a></li>
                    <li class="nav-item px-1"><a class="nav-link" href="#">신상품</a></li>
                    <li class="nav-item px-1"><a class="nav-link" href="#">남녀공용</a></li>
                    <li class="nav-item px-1"><a class="nav-link" href="#">여성용</a></li>
                    <li class="nav-item px-1"><a class="nav-link" href="#">남성용</a></li>
                    <li class="nav-item px-1"><a class="nav-link" href="#">바디&디퓨즈</a></li>
                    <li class="nav-item px-1"><a class="nav-link" href="#">커뮤니티</a></li>
                </ul>
            </div>
        </div>
    </nav>
</div>
<!-- End mainmenu area -->