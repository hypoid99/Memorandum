<?php
// ----------------------------------------------------
// Honey Soft (c) 2022
// Config
// ----------------------------------------------------
?>

<?php
//$_CONFIG["CDN_SERVER"] = "http://localhost:8008";
$_CONFIG["CDN_SERVER"] = "http://localhost";
$_CONFIG["LANGSET"] = $_COOKIE['lang_set'] ?? "kr";
?>