<?php
// ----------------------------------------------------
// Honey Soft (c) 2022
// logout.php
// ----------------------------------------------------
?>

<?php
session_start();
session_destroy();
echo "<script>alert('로그아웃 되었습니다.');location.href='/';</script>";
exit;
?>
