<?php
include $_SERVER["DOCUMENT_ROOT"]."/inc/dbcon.php";

$userid=$_POST["userid"];
$username=$_POST["username"];
$email=$_POST["email"];
$passwd=$_POST["passwd"];
$passwd=hash('sha512',$passwd);

$query2="select count(*) as cnt from members where userid='".$userid."' or email='".$email."'";//한번더 체크
$result2 = $mysqli->query($query2) or die("query error => ".$mysqli->error);
$rs2 = $result2->fetch_object();
if($rs2->cnt){
    echo "<script>alert('아이디나 이메일이 이미 가입된 정보입니다. 다시 한번 확인해주세요.');history.back();</script>";
    exit;
}

$sql="INSERT INTO members
        (userid, email, username, passwd)
        VALUES('".$userid."', '".$email."', '".$username."', '".$passwd."')";
$result=$mysqli->query($sql) or die($mysqli->error);


if($result){
    user_coupon($userid, 1, "회원가입");
    get_mileage($userid,1);
    echo "<script>alert('가입을 환영합니다. 10% 할인 쿠폰과 마일리지 1000원을 적립해 드렸습니다.');location.href='/index.php';</script>";
    exit;
}else{
    echo "<script>alert('회원가입에 실패했습니다.');history.back();</script>";
    exit;
}

?>