<?php
// ----------------------------------------------------
// Honey Soft (c) 2022
// DB Connection
// ----------------------------------------------------
?>

<?php
include $_SERVER["DOCUMENT_ROOT"]."/inc/config.php";

$hostname = "localhost";
$dbuserid = "admin";
$dbpasswd = "1111";
$dbname = "perfumemall_db";

$mysqli = new mysqli($hostname, $dbuserid, $dbpasswd, $dbname);
if ($mysqli->connect_errno) {
    die('Connect Error: '.$mysqli->connect_error);
}

// 이게 뭐임?
include $_SERVER["DOCUMENT_ROOT"]."/inc/lib.php";
?>