<?php
$_LANG['kr']['top']['myaccount'] = "내 계정";
$_LANG['en']['top']['myaccount'] = "My Account";
$_LANG['jp']['top']['myaccount'] = "アカウント";

$_LANG['kr']['top']['wishlist'] = "위시리스트";
$_LANG['en']['top']['wishlist'] = "Wish List";
$_LANG['jp']['top']['wishlist'] = "ウィッシュリスト";

$_LANG['kr']['top']['productregister'] = "제품등록";
$_LANG['en']['top']['productregister'] = "Product Register";
?>