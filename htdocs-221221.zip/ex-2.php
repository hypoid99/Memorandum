<section class="padding-y bg-light">
    <div class="container">
        <div class="row gy-4">
            <aside class="col-lg-4 col-md-6">
                <!-- =========== COMPONENT LOGIN 1=========== -->
                <div class="card">
                    <div class="card-body">
                        <h4 class="mb-4">Sign in</h4>
                        <form>
                            <div class="mb-3"> <label class="form-label">Email</label> <input name="lorem" class="form-control" placeholder="ex. name@gmail.com" type="email"> </div> <!-- col end.// -->
                            <div class="mb-3"> <label class="form-label">Password</label> <a class="float-end" href="#">Forgot?</a> <input class="form-control" placeholder="******" type="password"> </div> <!-- col end.// -->
                            <div class="mb-3"> <label class="form-check"> <input class="form-check-input" type="checkbox" value="" checked=""> <span class="form-check-label"> Remember </span> </label> </div> <button class="btn w-100 btn-primary" type="button"> Sign in </button>
                        </form> <!-- form end.// -->
                        <p class="text-divider my-4">New to shop?</p> <a href="#" class="btn w-100 btn-light">Create new accaunt</a>
                    </div> <!-- card-body end.// -->
                </div> <!-- card end.// -->
                <!-- ============= COMPONENT LOGIN 1 END.// ============= -->
            </aside> <!-- col end.// -->
            <aside class="col-lg-4 col-md-6">
                <!-- ============= COMPONENT LOGIN 2 ============ -->
                <div class="card">
                    <div class="card-body">
                        <h4 class="mb-4">Sign in</h4>
                        <form>
                            <div class="d-flex gap-2"> <a href="#" class="d-flex align-items-center btn btn-light w-100"> <img class="me-2" src="bootstrap5-ecommerce/images/icons/social/facebook.svg" height="20" width="20"> Facebook </a> <a href="#" class="d-flex align-items-center btn btn-light w-100"> <img class="me-2" src="bootstrap5-ecommerce/images/icons/social/google.svg" height="20" width="20"> Google </a> </div>
                            <p class="text-divider my-4"> Or login with username </p>
                            <div class="mb-3"> <input type="text" class="form-control" placeholder="Username"> </div>
                            <div class="mb-3 input-group"> <input type="password" class="form-control" placeholder="Password"> <button type="button" class="btn btn-light"> <i class="text-muted fa fa-eye"></i> </button> </div>
                            <div class="mb-3"> <label class="form-check"> <input class="form-check-input" type="checkbox" value="" checked=""> <span class="form-check-label"> Remember </span> </label> </div> <!-- col end.// -->
                            <div class="mb-4"> <button class="btn w-100 btn-primary" type="button"> Sign in </button> </div>
                            <p class="mb-1 text-center">Don’t have an account? <a href="#">Sign Up</a></p>
                        </form> <!-- form end.// -->
                    </div> <!-- card-body end.// -->
                </div> <!-- card end.// -->
                <!-- ============= COMPONENT LOGIN 2 END.// ============== -->
            </aside> <!-- col end.// -->
            <aside class="col-lg-4 col-md-6">
                <!-- ==============COMPONENT LOGIN 3 ============== -->
                <div class="card">
                    <div class="card-body">
                        <h4 class="mb-4">Sign in</h4>
                        <form>
                            <div class="input-group mb-3"> <span class="input-group-text"> <i class="fa fa-user"></i> </span> <input type="text" class="form-control" placeholder="Username"> </div> <!-- input-group end.// -->
                            <div class="input-group mb-3"> <span class="input-group-text"> <i class="fa fa-lock"></i> </span> <input type="text" class="form-control" placeholder="Password"> </div> <!-- input-group end.// -->
                            <div class="d-flex mb-3"> <label class="form-check me-auto"> <input class="form-check-input" type="checkbox" value="" checked=""> <span class="form-check-label"> Remember </span> </label> <a href="#" class="text-decoration-none">Forgot password</a> </div> <!-- col end.// --> <button class="btn btn-primary w-100" type="button"> Sign in </button>
                            <p class="text-divider my-4">or access via</p> <a href="#" class="btn btn-light w-100"> <img src="bootstrap5-ecommerce/images/icons/social/google.svg" height="20" width="20"> <span class="ms-1 align-middle">Continue with Google</span> </a>
                            <p class="mb-0 mt-4 text-center">Don’t have an account? <a href="#">Sign Up</a></p>
                        </form> <!-- form end.// -->
                    </div> <!-- card-body end.// -->
                </div> <!-- card end.// -->
                <!-- ============== COMPONENT LOGIN 3 END.// ============== -->
            </aside> <!-- col end.// -->
        </div> <!-- row end.// --> <br><br>
        <div class="row">
            <aside class="col-lg-6">
                <!-- ================ COMPONENT SIGNUP ================= -->
                <div class="card mb-4">
                    <article class="card-body">
                        <h4 class="mb-4">Create accaunt</h4>
                        <form>
                            <div class="row gx-3">
                                <div class="col mb-4"> <label class="form-label">First name</label> <input type="text" class="form-control" placeholder=""> </div> <!-- col end.// -->
                                <div class="col mb-4"> <label class="form-label">Last name</label> <input type="text" class="form-control" placeholder=""> </div> <!-- col end.// -->
                            </div> <!-- row end.// -->
                            <div class="row">
                                <div class="col-auto mb-3"> <label class="form-check"> <input class="form-check-input" type="radio" name="choose_a" checked=""> <span class="form-check-label"> Buyer </span> </label> </div> <!-- col end.// -->
                                <div class="col-auto mb-3"> <label class="form-check"> <input class="form-check-input" type="radio" name="choose_a"> <span class="form-check-label"> Seller </span> </label> </div> <!-- col end.// -->
                                <div class="col-auto mb-3"> <label class="form-check"> <input class="form-check-input" type="radio" name="choose_a"> <span class="form-check-label"> Both </span> </label> </div> <!-- col end.// -->
                            </div> <!-- row end.// -->
                            <div class="row gx-3">
                                <div class="col mb-3"> <label class="form-label">City</label> <input type="text" class="form-control"> </div> <!-- col end.// -->
                                <div class="col mb-3"> <label class="form-label">Country</label> <select class="form-select">
                                        <option value="none">Choose...</option>
                                        <option value="uz">Uzbekistan</option>
                                        <option value="ru">Russia</option>
                                        <option selected="">United States</option>
                                        <option value="in">India</option>
                                        <option value="af">Afganistan</option>
                                    </select> </div> <!-- col end.// -->
                                <div class="col-12 mb-3"> <label class="form-label">Address</label> <input type="text" class="form-control" placeholder=""> </div> <!-- col end.// -->
                                <div class="col-6 mb-3"> <label class="form-label">Email</label> <input type="email" class="form-control" placeholder=""> <small class="form-text">We'll never share your email</small> </div> <!-- col end.// -->
                                <div class="col-6 mb-3"> <label class="form-label">Phone</label>
                                    <div class="input-group"> <select class="form-select" style="max-width: 120px">
                                            <option value="us">US +1 </option>
                                            <option value="uz">UZ +998</option>
                                            <option value="ru">RU +72 </option>
                                        </select> <input type="email" class="form-control" placeholder=""> </div>
                                </div> <!-- col end.// -->
                                <div class="col mb-3"> <label class="form-label">Create password</label> <input class="form-control" type="password"> </div> <!-- col end.// -->
                                <div class="col mb-3"> <label class="form-label">Repeat password</label> <input class="form-control" type="password"> </div> <!-- col end.// -->
                            </div> <!-- row end.// -->
                            <div class="row mt-3 mb-4 align-items-center">
                                <div class="col-auto"> <button class="btn btn-primary" type="button">Register now</button> </div>
                                <div class="col"> <label class="form-check me-auto"> <input class="form-check-input" type="checkbox" value=""> <span class="form-check-label"> I agree with Terms and Conditions </span> </label> </div>
                            </div>
                        </form> <!-- form end.// -->
                        <hr>
                        <p class="mb-0">Already have an account? <a href="#">Sign in</a></p>
                    </article> <!-- card-body end .// -->
                </div> <!-- card end.// -->
                <!-- ============== COMPONENT SIGNUP END.// ============== -->
            </aside> <!-- col end.// -->
            <aside class="col-lg-6">
                <!-- ============== COMPONENT POSTING ============== -->
                <div class="card mb-4">
                    <article class="card-body">
                        <h4 class="mb-4">Submit product</h4>
                        <form>
                            <div class="row mb-4"> <label class="col-3 col-form-label">Title</label>
                                <div class="col-9"> <input type="text" class="form-control" placeholder="Type here"> </div> <!-- col end.// -->
                            </div> <!-- row end.// -->
                            <div class="row mb-4"> <label class="col-3 col-form-label">Price</label>
                                <div class="col-9"> <input type="text" class="form-control" placeholder="$ 0.00"> </div> <!-- col end.// -->
                            </div> <!-- row end.// -->
                            <div class="row mb-4"> <label class="col-3 col-form-label"> Image <br> <small class="text-muted">(Max 10 mb)</small> </label>
                                <div class="col-9">
                                    <div class="gallery-uploader-wrap"> <label style="width: 80px; height: 80px" class="uploader-img"> <img width="100" src="bootstrap5-ecommerce/images/items/1.webp"> </label> <label style="width: 80px; height: 80px" class="uploader-img"> <img width="100" src="bootstrap5-ecommerce/images/items/2.webp"> </label> <label style="width: 80px; height: 80px" class="uploader-img"> <input type="file" name="lorem"> <svg xmlns="http://www.w3.org/2000/svg" fill="#999" width="32" height="32" viewBox="0 0 24 24">
                                                <circle cx="12" cy="12" r="3"></circle>
                                                <path d="M16.83 4L15 2H9L7.17 4H2v16h20V4h-5.17zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5z"></path>
                                            </svg> </label> </div> <!-- gallery-uploader-wrap //end -->
                                </div> <!-- col end.// -->
                            </div> <!-- row end.// -->
                            <div class="row mb-4"> <label class="col-3 col-form-label">Description</label>
                                <div class="col-9"> <textarea class="form-control" placeholder="Type here"></textarea> </div> <!-- col end.// -->
                            </div> <!-- row end.// -->
                            <div class="row mb-4"> <label class="col-3 col-form-label">Brand</label>
                                <div class="col-9"> <select class="form-select" size="4">
                                        <option selected="">Select brand</option>
                                        <option value="1">Asus</option>
                                        <option value="2">Apple</option>
                                        <option value="3">Xuiaomi </option>
                                        <option value="4">Artel </option>
                                        <option value="6">Google </option>
                                    </select> </div> <!-- col end.// -->
                            </div> <!-- row end.// -->
                            <div class="row mb-4"> <label class="col-3 col-form-label">Features</label>
                                <div class="col-9">
                                    <ul class="row row-cols-xxl-3 row-cols-2">
                                        <li> <label class="form-check"> <input class="form-check-input" type="checkbox" value="" checked=""> <span class="form-check-label"> HD camera </span> </label> </li>
                                        <li> <label class="form-check"> <input class="form-check-input" type="checkbox" value="" checked=""> <span class="form-check-label"> Voice control </span> </label> </li>
                                        <li> <label class="form-check"> <input class="form-check-input" type="checkbox" value=""> <span class="form-check-label"> Metallic </span> </label> </li>
                                        <li> <label class="form-check"> <input class="form-check-input" type="checkbox" value=""> <span class="form-check-label"> 5K Display </span> </label> </li>
                                        <li> <label class="form-check"> <input class="form-check-input" type="checkbox" value=""> <span class="form-check-label"> High speed </span> </label> </li>
                                        <li> <label class="form-check"> <input class="form-check-input" type="checkbox" value=""> <span class="form-check-label"> Ultra wide </span> </label> </li>
                                        <li> <label class="form-check"> <input class="form-check-input" type="checkbox" value=""> <span class="form-check-label"> 5K Display </span> </label> </li>
                                        <li> <label class="form-check"> <input class="form-check-input" type="checkbox" value=""> <span class="form-check-label"> Blootooth 3.0 </span> </label> </li>
                                    </ul>
                                </div> <!-- col end.// -->
                            </div> <!-- row end.// -->
                            <div class="row mb-2">
                                <div class="col-9 offset-3"> <button type="button" class="btn btn-primary">Add product</button> <button type="reset" class="btn btn-outline-danger">Cancel</button> </div> <!-- col end.// -->
                            </div> <!-- row end.// -->
                        </form> <!-- form end.// -->
                    </article> <!-- card-body end .// -->
                </div> <!-- card end.// -->
                <!-- ============== COMPONENT POSTING END.// ============== -->
            </aside> <!-- col end.// -->
        </div> <!-- row end.// --> <br><br>
        <div class="row">
            <aside class="col-md-6">
                <!-- ============== COMPONENT FEEDBACK ============== -->
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Feedback</h4>
                        <form>
                            <div class="row gx-2">
                                <div class="col mb-3"> <label class="form-label">Name</label> <input type="text" class="form-control" placeholder=""> </div> <!-- col end.// -->
                                <div class="col mb-3"> <label class="form-label">Email</label> <input type="text" class="form-control" placeholder="example@mail.com"> </div> <!-- col end.// -->
                            </div> <!-- row end.// -->
                            <div class="mb-3"> <label class="form-label">What is message about?</label> <select class="form-select" id="select">
                                    <option selected="">Select</option>
                                    <option value="1">Technical issue</option>
                                    <option value="2">Money refund</option>
                                    <option value="3">Recommendation</option>
                                </select> </div>
                            <div class="mb-3"> <label class="form-label mb-1">Message</label> <textarea class="form-control" placeholder="Type" rows="3"></textarea> </div>
                            <div class="col mb-3"> <label class="form-label"> <input type="file" class="form-control"> </label> </div> <!-- col end.// --> <button class="btn btn-primary" type="button">Send message</button>
                        </form> <!-- form end.// -->
                    </div> <!-- card-body end.// -->
                </div> <!-- card end.// -->
                <!-- ============== COMPONENT FEEDBACK END.// ============== -->
            </aside> <!-- col end.// -->
            <aside class="col-md-6">
                <!-- ============== COMPONENT CATEGORY =============== -->
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Category selection</h5>
                        <div> <label class="box box-check mb-2" style="width: 140px"> <input checked="" class="position-absolute form-check-input" type="checkbox" name="lorem"> <b class="border-oncheck"></b> <span class="d-block text-center"> <img class="icon-xs" width="32" height="32" src="bootstrap5-ecommerce/images/icons/category-svg-blue/ball.svg">
                                    <p class="m-0">Sport items</p>
                                </span> </label> <label class="box box-check mb-2" style="width: 140px"> <input checked="" class="position-absolute form-check-input" type="checkbox" name="lorem"> <b class="border-oncheck"></b> <span class="d-block text-center"> <img class="icon-xs" width="32" height="32" src="bootstrap5-ecommerce/images/icons/category-svg-blue/book.svg">
                                    <p class="m-0">Books</p>
                                </span> </label> <label class="box box-check mb-2" style="width: 140px"> <input class="position-absolute form-check-input" type="checkbox" name="lorem"> <b class="border-oncheck"></b> <span class="d-block text-center"> <img class="icon-xs" width="32" height="32" src="bootstrap5-ecommerce/images/icons/category-svg-blue/cpu.svg">
                                    <p class="m-0">Computers</p>
                                </span> </label> <label class="box box-check mb-2" style="width: 140px"> <input class="position-absolute form-check-input" type="checkbox" name="lorem"> <b class="border-oncheck"></b> <span class="d-block text-center"> <img class="icon-xs" width="32" height="32" src="bootstrap5-ecommerce/images/icons/category-svg-blue/animal.svg">
                                    <p class="m-0">Animals</p>
                                </span> </label> <label class="box box-check mb-2" style="width: 140px"> <input class="position-absolute form-check-input" type="checkbox" name="lorem"> <b class="border-oncheck"></b> <span class="d-block text-center"> <img class="icon-xs" width="32" height="32" src="bootstrap5-ecommerce/images/icons/category-svg-blue/education.svg">
                                    <p class="m-0">Education</p>
                                </span> </label> <label class="box box-check mb-2" style="width: 140px"> <input class="position-absolute form-check-input" type="checkbox" name="lorem"> <b class="border-oncheck"></b> <span class="d-block text-center"> <img class="icon-xs" width="32" height="32" src="bootstrap5-ecommerce/images/icons/category-svg-blue/med-tooth.svg">
                                    <p class="m-0">Medicine</p>
                                </span> </label> <label class="box box-check mb-2" style="width: 140px"> <input class="position-absolute form-check-input" type="checkbox" name="lorem"> <b class="border-oncheck"></b> <span class="d-block text-center"> <img class="icon-xs" width="32" height="32" src="bootstrap5-ecommerce/images/icons/category-svg-blue/shirt.svg">
                                    <p class="m-0">Fashion</p>
                                </span> </label> </div>
                    </div> <!-- card-body end.// -->
                </div> <!-- card end.// -->
                <!-- ============== COMPONENT CATEGORY END.// ============== -->
                <!-- ============== COMPONENT IMAGE UPLOAD =============== -->
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Image uploads</h5>
                        <div class="gallery-uploader-wrap"> <label class="uploader-img"> <img width="100" src="bootstrap5-ecommerce/images/items/1.webp"> </label> <label class="uploader-img"> <img width="100" src="bootstrap5-ecommerce/images/items/2.webp"> </label> <label class="uploader-img"> <input type="file" name="lorem"> <svg xmlns="http://www.w3.org/2000/svg" fill="#999" width="32" height="32" viewBox="0 0 24 24">
                                    <circle cx="12" cy="12" r="3"></circle>
                                    <path d="M16.83 4L15 2H9L7.17 4H2v16h20V4h-5.17zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5z"></path>
                                </svg> </label> <label class="uploader-img"> <input type="file" name="lorem"> <svg xmlns="http://www.w3.org/2000/svg" fill="#999" width="32" height="32" viewBox="0 0 24 24">
                                    <circle cx="12" cy="12" r="3"></circle>
                                    <path d="M16.83 4L15 2H9L7.17 4H2v16h20V4h-5.17zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5z"></path>
                                </svg> </label> </div> <!-- gallery-uploader-wrap //end -->
                    </div> <!-- card-body end.// -->
                </div> <!-- card end.// -->
                <!-- ============== COMPONENT IMAGE UPLOAD END.// ============== -->
            </aside> <!-- col end.// -->
        </div> <!-- row end.// -->
    </div> <!-- container end.// -->
</section>