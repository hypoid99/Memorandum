<?php
// ----------------------------------------------------
// Honey Soft (c) 2022
// dbcon.php
// ----------------------------------------------------
?>

<?php
$hostname = "localhost";
$dbuserid = "admin";
$dbpasswd = "1111";
$dbname = "testdb";
$mysqli = new mysqli($hostname, $dbuserid, $dbpasswd, $dbname);
if ($mysqli->connect_errno) {
    die('Connect Error: '.$mysqli->connect_error);
}
?>
