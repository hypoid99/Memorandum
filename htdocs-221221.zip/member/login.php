<?php
// ----------------------------------------------------
// Honey Soft (c) 2022
// Login
// ----------------------------------------------------
?>

<?php
include $_SERVER["DOCUMENT_ROOT"]."/inc/top.php";
?>

<section class="padding-y">
    <div class="container">
        <div class="row gy-4 justify-content-center">
            <aside class="col-lg-4 col-md-8">
                <div class="card">
                    <div class="card-body">
                        <h4 class="mb-4">로그인</h4>
                        <form method="post" action="/member/login_ok.php">
                            <div class="input-group mb-3"> <span class="input-group-text"> <i class="fa fa-user"></i> </span> <input type="text" class="form-control" id="userid" name="userid" placeholder="아이디" required> </div>
                            <div class="input-group mb-3"> <span class="input-group-text"> <i class="fa fa-lock"></i> </span> <input type="password" class="form-control" id="passwd" name="passwd" placeholder="비밀번호" required> </div>
                            <div class="d-flex mb-3"> <label class="form-check me-auto"> <input class="form-check-input" type="checkbox" value="" checked=""> 
                                <span class="form-check-label"> 아이디 기억하기 </span> </label> 
                                <a href="#" class="text-decoration-none">비밀번호 찾기</a> 
                            </div>
                            <button class="btn btn-primary w-100" type="submit"> 로그인 </button>
                            <p class="mb-0 mt-4 text-center">아직 Parfume Story의 회원이 아니신가요??</p>
                            <p class="mb-0 text-center">회원가입하고 다양한 혜택과 서비스를 이용해 보세요!</p>
                            <p class="mb-0 text-center"><a href="#">회원가입</a></p>
                        </form>
                    </div>
                </div>
            </aside>
        </div><br><br>
    </div>
</section>

<?php
include $_SERVER["DOCUMENT_ROOT"]."/inc/bot.php";
?>