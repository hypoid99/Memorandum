<?php
// ----------------------------------------------------
// Honey Soft (c) 2022
// Product Delete
// ----------------------------------------------------
?>

<?php
session_start();
include $_SERVER["DOCUMENT_ROOT"]."/inc/dbcon.php";

if (!$_SESSION['AUID']) {
    echo "<script> alert('권한이 없습니다.'); location.href='/admin/login.php'; </script>";
    exit;
}

$pid = $_POST["pid"] ?? $_GET["pid"];

if ($pid) {
    $result = $mysqli->query("select * from products where pid=".$pid) or die("query error => ".$mysqli->error);
    $rs = $result->fetch_object();

    //$sql = "update board set status=0 where bid=".$bid; //status값을 0 바꿔서 삭제 처리한다
    $sql = "delete from products where pid=".$pid;
    $result = $mysqli->query($sql) or die($mysqli->error);

    // 첨부된 이미지 파일 삭제
    $file_result = $mysqli->query("select * from product_image_table where pid=".$pid) or die("query error => ".$mysqli->error);
    while ($rs = $file_result->fetch_object()) {
        $delete_file = $_SERVER['DOCUMENT_ROOT'].$rs->filename;
        unlink($delete_file);
    }
    // 이미지 DB 삭제
    $result1 = $mysqli->query("select * from product_image_table where pid=".$pid) or die("query error => ".$mysqli->error);
    $rs = $result1->fetch_object();
    $sql = "delete from product_image_table where pid=".$pid;
    $result1 = $mysqli->query($sql) or die($mysqli->error);

    // WMS 재고창고 삭제
    $result2 = $mysqli->query("select * from wms where pid=".$pid) or die("query error => ".$mysqli->error);
    $rs = $result2->fetch_object();
    $sql = "delete from wms where pid=".$pid;
    $result2 = $mysqli->query($sql) or die($mysqli->error);
} else {
    echo "<script>alert('삭제할 수 없습니다.');history.back();</script>";
    exit;
}

if ($result) {
    echo "<script>alert('삭제했습니다.');location.href='/admin/product/product_list.php';</script>";
    exit;
}else{
    echo "<script>alert('글삭제에 실패했습니다.');history.back();</script>";
    exit;
}

?>
