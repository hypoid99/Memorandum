<?php
include $_SERVER["DOCUMENT_ROOT"]."/inc/top.php";

if (!$_SESSION['AUID']) {
  echo "<script> alert('제품리스트 권한이 없습니다.'); location.href='/admin/login.php'; </script>";
  exit;
}

$pid = $_GET['pid'];

$query = "select *, (select sum(cnt) from wms w where w.pid=p.pid) as sumcnt from products p where pid=".$pid;
$result = $mysqli->query($query) or die("query error => ".$mysqli->error);
$rs = $result->fetch_object();

// 카테고리 Query - Option 1 (컬러)
$query2 = "select * from product_options where cate='컬러' and pid=".$pid;
$result2 = $mysqli->query($query2) or die("query error => ".$mysqli->error);
while ($rs2 = $result2->fetch_object()) {
    $options1[] = $rs2;
}

// 카테고리 Query - Option 2 (사이즈)
$query2 = "select * from product_options where cate='OPT01' and pid=".$pid;
$result2 = $mysqli->query($query2) or die("query error => ".$mysqli->error);
while ($rs2 = $result2->fetch_object()) {
    $options2[] = $rs2;
}

// 상품 설명 이미지 Query
$query3 = "select * from product_image_table where pid=".$pid;
$result3 = $mysqli->query($query3) or die("query error => ".$mysqli->error);
while ($rs3 = $result3->fetch_object()) {
    $imgfile[] = $rs3;
}
?>

<style>
.col {
    border: 1px solid #f1f1f1;
}

[type=radio]+span {
    cursor: pointer;
}

[type=radio]:checked+span {
    outline: 1px solid indigo;
}
</style>

<div>
    <h1 class="p-3" style="text-align:center;">제품 내용 보기</h1>
</div>
<div>
    <h5 style="text-align:center;"><?php echo $query ?></h5>
    <h5 style="text-align:center;"><?php echo $query2 ?></h5>
</div>
<div class="container">
    <div class="row">
        <div class="col" style="text-align:center;">
            <img id="pimg" src="<?php echo $rs->thumbnail;?>" style="max-width:200px;">
        </div>
        <div class="col">
            <h3><?php echo $rs->name;?></h3>
            <div>
                가격 : <span id="price"><?php echo number_format($rs->price);?></span>원<br>
                재고 : <span id="cnt"><?php echo number_format($rs->sumcnt);?></span>EA
            </div>
            <div>
                옵션 :
                <form>
                    <?php if (isset($options2)) foreach ($options2 as $op2) {
                    $option_name = $op2->option_name;
                    if ($op2->option_price) $option_name.=" (+".number_format($op2->option_price)."원 추가)";
                    ?>
                    <div>
                        <input type="radio" name="poption2" id="poption2_<?php echo $op2->poid; ?>" value="<?php echo $op2->poid; ?>">
                        <span onclick="jQuery('#poption2_<?php echo $op2->poid;?>').click();"><?php echo $option_name; ?></span>
                        </input>
                    </div>
                    <?php }?>
                </form>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col" style="text-align:center;">
            <h3 class="p-3" style="text-align:center;">제품 상세 정보</h3>
            <?php foreach($imgfile as $imgurl){?>
                <span style="content:url(<?php echo $imgurl->filename;?>);"></span>
            <?php }?>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <h3 class="p-3" style="text-align:center;">상품 구매 안내</h3>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <h3 class="p-3" style="text-align:center;">제품 사용 후기</h3>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <h3 class="p-3" style="text-align:center;">제품 Q&A</h3>
        </div>
    </div>
</div>
<hr>

<script>
$("input[name='poption2']:radio").change(function() {
    var poid2 = $('input:radio[name="poption2"]:checked').val();
    var data = {
        poid2: poid2
    };
    $.ajax({
        async: false,
        type: 'post',
        url: 'option_change.php',
        data: data,
        dataType: 'json',
        error: function(request, status, error) {
            //alert("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
        },
        success: function(data) {
            //alert ('ajax success');
            console.log(data);
            var price = parseInt(data.option_price2) + <?php echo $rs->price;?>;
            $("#price").text(number_format(price));
            $("#cnt").text(number_format(data.cnt));
        }
    });
});

function number_format(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}


$("#poption").change(function() {
    alert('poption change');
    var poid = $("#poption option:selected").val();
    var data = {
        poid: poid
    };
    $.ajax({
        async: false,
        type: 'post',
        url: 'option_change.php',
        data: data,
        dataType: 'json',
        error: function() {},
        success: function(data) {
            var price = parseInt(data.option_price) + <?php echo $rs->price;?>;
            $("#pimg").attr("src", data.image_url);
            $("#price").text(number_format(price));
        }
    });
});
</script>

<?php
include $_SERVER["DOCUMENT_ROOT"]."/inc/bot.php";
?>