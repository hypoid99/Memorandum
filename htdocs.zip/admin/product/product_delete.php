<?php
// ----------------------------------------------------
// Honey Soft (c) 2022
// Product Delete
// ----------------------------------------------------
?>

<?php
session_start();
include $_SERVER["DOCUMENT_ROOT"]."/inc/header.php";

if (!$_SESSION['AUID']) {
    echo "<script> alert('권한이 없습니다.'); location.href='/admin/login.php'; </script>";
    exit;
}

$pid = $_POST["pid"] ?? $_GET["pid"];

if ($pid) {
    $result = $mysqli->query("select * from products where pid=".$pid) or die("query error => ".$mysqli->error);
    $rs = $result->fetch_object();

    //$sql = "update board set status=0 where bid=".$bid; //status값을 0 바꿔서 삭제 처리한다
    $sql = "delete from products where pid=".$pid;
    $result = $mysqli->query($sql) or die($mysqli->error);

    // 첨부된 파일이 있으면 디비에서 조회후 모두 삭제해준다.
    $file_result = $mysqli->query("select * from product_image_table where pid=".$pid) or die("query error => ".$mysqli->error);
    while ($rs = $file_result->fetch_object()) {
        $delete_file = $_SERVER["DOCUMENT_ROOT"]."/pdata/".$rs->filename;
        unlink($delete_file);
    }
} else {
    echo "<script>alert('삭제할 수 없습니다.');history.back();</script>";
    exit;
}

if ($result) {
    echo "<script>alert('삭제했습니다.');location.href='/admin/product/product_list.php';</script>";
    exit;
}else{
    echo "<script>alert('글삭제에 실패했습니다.');history.back();</script>";
    exit;
}

?>
