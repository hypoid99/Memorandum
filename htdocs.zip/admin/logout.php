<?php
session_start();
session_destroy();
echo "<script>alert('관리자 로그아웃 되었습니다.');location.href='/';</script>";
exit;
?>
