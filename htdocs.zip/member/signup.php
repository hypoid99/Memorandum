<?php
include $_SERVER["DOCUMENT_ROOT"]."/inc/header.php";
?>

        <form class="row g-3 needs-validation" method="post" action="/member/signup_ok.php">
        <div class="col-12">
            <label for="validationCustom01" class="form-label">이름</label>
            <input type="text" class="form-control" id="userame" name="username" placeholder="" required>
        </div>
        <div class="col-12">
            <label for="validationCustom02" class="form-label">아이디</label>
            <input type="text" class="form-control" id="userid" name="userid" placeholder="" required>
        </div>
        <div class="col-12">
            <label for="validationCustom02" class="form-label">비밀번호</label>
            <input type="password" class="form-control" id="passwd" name="passwd" placeholder="" required>
        </div>
        <div class="col-12">
            <label for="validationCustomUsername" class="form-label">이메일</label>
            <div class="input-group has-validation">
            <span class="input-group-text" id="inputGroupPrepend">@</span>
            <input type="email" class="form-control" id="email" name="email" placeholder="" required>
            </div>
        </div>
       
        <div class="col-12"><!-- button은 기본 type이 submit 이다. button을 submit으로 쓰지 않을때는 반드시 type="button"을 넣어줘야한다. -->
            <button type="button" class="btn btn-primary" id="signup">가입하기</button>
        </div>
        </form>
<script>
    $('#signup').click(function(){

        var userid = $("#userid").val();
        var email = $("#email").val();
       
        var data = {
            userid : userid,
            email : email
        };
            $.ajax({
                async : false,
                type : 'post' ,
                url : 'signup_check.ajax.php' ,
                data  : data ,
                dataType : 'json' ,//json으로 받음.
                error : function() {} ,
                success : function(return_data) {
                    if(return_data.cnt>0){//조회값이 있으면
                        alert('아이디나 이메일이 이미 가입된 정보입니다. 다시 한번 확인해주세요.');
                        return false;
                    }else{
                        $("form").submit();
                    }
                }
        });
       
    });
</script>
<?php
include $_SERVER["DOCUMENT_ROOT"]."/inc/footer.php";
?>