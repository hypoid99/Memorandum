<?php session_start();
include $_SERVER["DOCUMENT_ROOT"]."/inc/dbcon.php";
ini_set( 'display_errors', '0' );

$userid = $_POST['userid'];
$email = $_POST['email'];

$query2="select count(*) as cnt from members where userid='".$userid."' or email='".$email."'";
$result2 = $mysqli->query($query2) or die("query error => ".$mysqli->error);
$rs2 = $result2->fetch_object();

$data = array("cnt"=>$rs2->cnt);//cnt에 값이 있으면 이미 사용중인 값이다.
echo json_encode($data);

?>