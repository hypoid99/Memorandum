<?php
// ----------------------------------------------------
// Honey Soft (c) 2022
// Logout
// ----------------------------------------------------
?>

<?php
session_start();
include $_SERVER["DOCUMENT_ROOT"]."/inc/dbcon.php";

$userid = $_SESSION["UID"];

$query = "select * from members where userid='".$userid."'";
$result = $mysqli->query($query) or die("query error => ".$mysqli->error);
$rs = $result->fetch_object();

if ($rs) {
    $sql = "update members set last_logout=now() where mid=".$rs->mid;
    $result = $mysqli->query($sql) or die($mysqli->error);
}

session_destroy();
echo "<script>alert('로그아웃 되었습니다.'); location.href='/';</script>";
exit;
?>
