<?php
include $_SERVER["DOCUMENT_ROOT"]."/inc/html_header.html";
?>

<section class="padding-y bg-light">
    <div class="container">
        <div class="row gy-4">
            <aside class="col-lg-4 col-md-8">
                <!-- ==============COMPONENT LOGIN 3 ============== -->
                <div class="card">
                    <div class="card-body">
                        <h4 class="mb-4">Sign in</h4>
                        <form>
                            <div class="input-group mb-3"> <span class="input-group-text"> <i class="fa fa-user"></i> </span> <input type="text" class="form-control" placeholder="Username"> </div> <!-- input-group end.// -->
                            <div class="input-group mb-3"> <span class="input-group-text"> <i class="fa fa-lock"></i> </span> <input type="text" class="form-control" placeholder="Password"> </div> <!-- input-group end.// -->
                            <div class="d-flex mb-3"> <label class="form-check me-auto"> <input class="form-check-input" type="checkbox" value="" checked=""> <span class="form-check-label"> Remember </span> </label> <a href="#" class="text-decoration-none">Forgot password</a> </div> <!-- col end.// --> <button class="btn btn-primary w-100" type="button"> Sign in </button>
                            <p class="text-divider my-4">or access via</p> <a href="#" class="btn btn-light w-100"> <img src="https://bootstrap-ecommerce.com/bootstrap5-ecommerce/images/icons/social/google.svg" height="20" width="20"> <span class="ms-1 align-middle">Continue with Google</span> </a>
                            <p class="mb-0 mt-4 text-center">Don’t have an account? <a href="#">Sign Up</a></p>
                        </form> <!-- form end.// -->
                    </div> <!-- card-body end.// -->
                </div> <!-- card end.// -->
                <!-- ============== COMPONENT LOGIN 3 END.// ============== -->
            </aside> <!-- col end.// -->
        </div> <!-- row end.// --> <br><br>
    </div> <!-- container end.// -->
</section>

<?php
include $_SERVER["DOCUMENT_ROOT"]."/inc/html_footer.html";
?>