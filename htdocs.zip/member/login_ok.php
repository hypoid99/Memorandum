<?php
// ----------------------------------------------------
// Honey Soft (c) 2022
// Login OK 체크
// ----------------------------------------------------
?>

<?php 
session_start();
include $_SERVER["DOCUMENT_ROOT"]."/inc/dbcon.php";

$userid = $_POST["userid"];
$passwd = $_POST["passwd"];
$passwd = hash('sha512',$passwd);

$query = "select * from members where userid='".$userid."' and passwd='".$passwd."'";
$result = $mysqli->query($query) or die("query error => ".$mysqli->error);
$rs = $result->fetch_object();

if ($rs) {
    $sql = "update members set last_login=now() where mid=".$rs->mid;
    $result = $mysqli->query($sql) or die($mysqli->error);

    $_SESSION['UID'] = $rs->userid;
    $_SESSION['UNAME'] = $rs->username;

    if (($rs->level) == 1) {
        $_SESSION['AUID'] = $rs->userid;
        $_SESSION['AUNAME'] = $rs->username;
        $_SESSION['ALEVEL'] = $rs->level;



        echo "<script>alert('관리자님 어서오십시오.');location.href='/';</script>";
        exit;
    }

    //로그인하면 장바구니에 세션아이디가 같은 제품들의 userid를 업데이트한다.
    $sql="update cart set userid='".$userid."' where ssid='".session_id()."'";
    $result=$mysqli->query($sql) or die($mysqli->error);

    $query2 = "select count(*) as cnt from mileage_history where userid='".$userid."' and type=2 and status=1 and DATE(regdate) = DATE(NOW())";
    $result2 = $mysqli->query($query2) or die("query error => ".$mysqli->error);
    $rs2 = $result2->fetch_object();
    if (!$rs2->cnt) { // 오늘 등록한 마일리지가 없으면 함수 실행
        get_mileage($userid,2); //로그인 이벤트
    }

    echo "<script>alert('회원님 어서오십시오.');location.href='/';</script>";
    exit;
} else {
    echo "<script>alert('아이디나 암호가 틀렸습니다. 다시한번 확인해주십시오.');history.back();</script>";
    exit;
}

?>