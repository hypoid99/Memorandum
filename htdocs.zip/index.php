<?php
include $_SERVER["DOCUMENT_ROOT"]."/inc/top.php";

global $cvalarray;

$sql = "select * from products p where 1=1 and ismain=1 and status=1";
$order = " order by pid desc";
$limit = " limit 5";
$query = $sql.$order.$limit;
$result = $mysqli->query($query) or die ("query error => ".$mysqli->error);
while ($rs = $result->fetch_object()) {
    $rsc[] = $rs;
}
?>

<!-- Start slider area -->
<div class="slider-area">
    <div id="slide-list" class="carousel carousel-fade slide" data-bs-ride="carousel">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="carousel-indicators">
                        <button type="button" data-bs-target="#slide-list" data-bs-slide-to="0" class="active"></button>
                        <button type="button" data-bs-target="#slide-list" data-bs-slide-to="1"></button>
                        <button type="button" data-bs-target="#slide-list" data-bs-slide-to="2"></button>
                    </div>
                </div>
            </div>
        </div>
        <div class="carousel-inner">
            <div class="carousel-item active" data-bs-interval="3000">
                <div class="slide-wrapper">
                    <img src="img/slide-1.jpg" class="d-block w-100">
                    <div class="carousel-caption">
                        <a href="#">
                            <h3>Slide-1</h3>
                        </a>
                        <p>Wecome to Parfume Story</p>
                    </div>
                </div>
            </div>
            <div class="carousel-item" data-bs-interval="3000">
                <div class="slide-wrapper">
                    <img src="img/slide-2.jpg" class="d-block w-100">
                    <div class="carousel-caption">
                        <a href="#">
                            <h3>Slide-2</h3>
                        </a>
                        <p>Wecome to Parfume Story</p>
                    </div>
                </div>
            </div>
            <div class="carousel-item" data-bs-interval="3000">
                <div class="slide-wrapper">
                    <img src="img/slide-3.jpg" class="d-block w-100">
                    <div class="carousel-caption">
                        <a href="#">
                            <h3>Slide-3</h3>
                        </a>
                        <p>Wecome to Parfume Story</p>
                    </div>
                </div>
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#slide-list" data-bs-slide="prev">
            <span class="carousel-control-prev-icon"></span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#slide-list" data-bs-slide="next">
            <span class="carousel-control-next-icon"></span>
        </button>
    </div>
</div>
<!-- End slider area -->
<br>
<br>
<br>
<!-- Start promotion area -->
<!--
    <div class="promo-area">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6">
                    <div class="single-promo">
                        <i class="fa fa-refresh"></i>
                        <p>30 Days return</p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="single-promo">
                        <i class="fa fa-truck"></i>
                        <p>Free shipping</p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="single-promo">
                        <i class="fa fa-lock"></i>
                        <p>Secure payments</p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="single-promo">
                        <i class="fa fa-gift"></i>
                        <p>New products</p>
                    </div>
                </div>
            </div>
        </div>
    </div> 
-->
<!-- End promotion area -->

<!-- Start main content area -->
<div class="maincontent-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="latest-product">
                    <h2 class="section-title">Latest Products</h2>
                    <div class="product-carousel">
                        <?php foreach ($rsc as $p) { ?>
                        <div class="single-product">
                            <div class="product-f-image">
                                <img src="<?php echo $p->thumbnail;?>" style="height:272px;" alt="">
                                <div class="product-hover">
                                    <a href="#" class="add-to-cart-link"><i class="fa fa-shopping-cart"></i> Add to cart</a>
                                    <a href="products.php?pid=<?php echo $p->pid;?>" class="view-details-link"><i class="fa fa-link"></i> See details</a>
                                </div>
                            </div>
                            <h2><a href="products.php?pid=<?php echo $p->pid;?>"><?php echo $p->name;?></a></h2>
                            <div class="product-carousel-price">
                                <ins><?php echo number_format($p->sale_price);?>원</ins> <del><?php echo number_format($p->price);?>원</del>
                            </div>
                        </div>
                        <?php }?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End main content area -->

<!-- Start brands area -->
<!--
    <div class="brands-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="brand-wrapper">
                        <h2 class="section-title">Brands</h2>
                        <div class="brand-list">
                            <img src="img/services_logo__1.jpg" alt="">
                            <img src="img/services_logo__2.jpg" alt="">
                            <img src="img/services_logo__3.jpg" alt="">
                            <img src="img/services_logo__4.jpg" alt="">
                            <img src="img/services_logo__1.jpg" alt="">
                            <img src="img/services_logo__2.jpg" alt="">
                            <img src="img/services_logo__3.jpg" alt="">
                            <img src="img/services_logo__4.jpg" alt="">                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> 
-->
<!-- End brands area -->

<!-- Start product widget area -->
<div class="product-widget-area">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="single-product-widget">
                    <h2 class="product-wid-title">Top Sellers</h2>
                    <a href="" class="wid-view-more">View All</a>
                    <div class="single-wid-product">
                        <a href="products.php"><img src="img/product-thumb-1.jpg" alt="" class="product-thumb"></a>
                        <h2><a href="products.php">Sony Smart TV - 2015</a></h2>
                        <div class="product-wid-rating">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                        </div>
                        <div class="product-wid-price">
                            <ins>$400.00</ins> <del>$425.00</del>
                        </div>
                    </div>
                    <div class="single-wid-product">
                        <a href="products.php"><img src="img/product-thumb-2.jpg" alt="" class="product-thumb"></a>
                        <h2><a href="products.php">Apple new mac book 2015</a></h2>
                        <div class="product-wid-rating">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                        </div>
                        <div class="product-wid-price">
                            <ins>$400.00</ins> <del>$425.00</del>
                        </div>
                    </div>
                    <div class="single-wid-product">
                        <a href="products.php"><img src="img/product-thumb-3.jpg" alt="" class="product-thumb"></a>
                        <h2><a href="products.php">Apple new i phone 6</a></h2>
                        <div class="product-wid-rating">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                        </div>
                        <div class="product-wid-price">
                            <ins>$400.00</ins> <del>$425.00</del>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="single-product-widget">
                    <h2 class="product-wid-title">Recently Viewed</h2>
                    <a href="#" class="wid-view-more">View All</a>
                    <?php
if ($_COOKIE['recently_products']) { //쿠키에 값이 있으면
    $prs = json_decode($_COOKIE['recently_products']); //배열로 바꾼다.
    krsort($prs); //키값 기준으로 역순으로 정렬한다. 최근에 본걸 맨위에 올리기 위해서다.
    $t=0;
    foreach($prs as $ps){
?>
                    <div class="single-wid-product">
                        <a href="products.php?pid=<?php echo $ps->pid;?>"><img src="<?php echo $ps->thumbnail;?>" alt="" class="product-thumb"></a>
                        <h2><a href="products.php?pid=<?php echo $ps->pid;?>"><?php echo $ps->name;?></a></h2>
                        <div class="product-wid-price">
                            <ins><?php echo number_format($ps->sale_price);?>원</ins> <del><?php echo number_format($ps->price);?>원</del>
                        </div>
                    </div>
                    <?php
    $t++;
    }
}
?>
                </div>
            </div>
            <div class="col-md-4">
                <div class="single-product-widget">
                    <h2 class="product-wid-title">Top New</h2>
                    <a href="#" class="wid-view-more">View All</a>
                    <div class="single-wid-product">
                        <a href="products.php"><img src="img/product-thumb-3.jpg" alt="" class="product-thumb"></a>
                        <h2><a href="products.php">Apple new i phone 6</a></h2>
                        <div class="product-wid-rating">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                        </div>
                        <div class="product-wid-price">
                            <ins>$400.00</ins> <del>$425.00</del>
                        </div>
                    </div>
                    <div class="single-wid-product">
                        <a href="products.php"><img src="img/product-thumb-4.jpg" alt="" class="product-thumb"></a>
                        <h2><a href="products.php">Samsung gallaxy note 4</a></h2>
                        <div class="product-wid-rating">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                        </div>
                        <div class="product-wid-price">
                            <ins>$400.00</ins> <del>$425.00</del>
                        </div>
                    </div>
                    <div class="single-wid-product">
                        <a href="products.php"><img src="img/product-thumb-1.jpg" alt="" class="product-thumb"></a>
                        <h2><a href="products.php">Sony playstation microsoft</a></h2>
                        <div class="product-wid-rating">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                        </div>
                        <div class="product-wid-price">
                            <ins>$400.00</ins> <del>$425.00</del>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End product widget area -->

<?php
include $_SERVER["DOCUMENT_ROOT"]."/inc/bot.php";
?>